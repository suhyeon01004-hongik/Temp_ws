#pragma once

#include <string>

namespace vehicle_control {

struct SpeedControllerConfig {
  double accelerator_gain;
  double brake_gain;
  double deadband_mps;
  double maximum_accelerator_command;
  double maximum_brake_command;
};

struct PedalCommand {
  bool valid;
  double accelerator;
  double brake;
  std::string error;
};

class SpeedController {
 public:
  explicit SpeedController(const SpeedControllerConfig& config);

  PedalCommand calculate(double current_speed_mps,
                         double target_speed_mps) const;

 private:
  SpeedControllerConfig config_;
  bool config_valid_;
  std::string config_error_;
};

}  // namespace vehicle_control
