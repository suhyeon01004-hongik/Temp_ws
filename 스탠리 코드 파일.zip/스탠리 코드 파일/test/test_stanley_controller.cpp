#include <gtest/gtest.h>

#include <cmath>
#include <limits>
#include <vector>

#include "vehicle_control/path_point.hpp"
#include "vehicle_control/stanley_controller.hpp"

namespace vehicle_control {
namespace {

constexpr double kPi = 3.14159265358979323846;

StanleyConfig makeConfig() {
  return StanleyConfig{3.0, 1.0, 1.0, 0.1, 40.0 * kPi / 180.0,
                       120.0 * kPi / 180.0};
}

TEST(StanleyController, StraightCenteredPathHasZeroError) {
  const std::vector<PathPoint> path{{0.0, 0.0}, {5.0, 0.0}, {10.0, 0.0}};
  const StanleyResult result =
      StanleyController(makeConfig()).calculate(path, 5.0, 0.0, 0.02);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(0.0, result.cross_track_error_m, 1e-9);
  EXPECT_NEAR(0.0, result.heading_error_rad, 1e-9);
  EXPECT_NEAR(0.0, result.steering_angle_rad, 1e-9);
}

TEST(StanleyController, PathOnLeftProducesPositiveSteering) {
  const std::vector<PathPoint> path{{0.0, 1.0}, {5.0, 1.0}, {10.0, 1.0}};
  const StanleyResult result =
      StanleyController(makeConfig()).calculate(path, 5.0, 0.0, 1.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_GT(result.cross_track_error_m, 0.0);
  EXPECT_GT(result.steering_angle_rad, 0.0);
}

TEST(StanleyController, PathOnRightProducesNegativeSteering) {
  const std::vector<PathPoint> path{{0.0, -1.0}, {5.0, -1.0}, {10.0, -1.0}};
  const StanleyResult result =
      StanleyController(makeConfig()).calculate(path, 5.0, 0.0, 1.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_LT(result.cross_track_error_m, 0.0);
  EXPECT_LT(result.steering_angle_rad, 0.0);
}

TEST(StanleyController, NinetyDegreeCornerSaturatesAtMaximumSteeringAngle) {
  const std::vector<PathPoint> path{{0.0, -1.0}, {3.0, -1.0},
                                    {3.0, 5.0}};
  const StanleyResult result =
      StanleyController(makeConfig()).calculate(path, 5.0, 0.0, 1.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(40.0 * kPi / 180.0, result.steering_angle_rad, 1e-9);
}

TEST(StanleyController, SteeringRateLimitsTwentyMillisecondTransition) {
  const std::vector<PathPoint> path{{0.0, 10.0}, {5.0, 10.0}};
  const StanleyResult result =
      StanleyController(makeConfig()).calculate(path, 5.0, 0.0, 0.02);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(120.0 * kPi / 180.0 * 0.02, result.steering_angle_rad,
              1e-9);
}

TEST(StanleyController, ZeroSpeedProducesFiniteSteeringAngle) {
  const std::vector<PathPoint> path{{0.0, 1.0}, {5.0, 1.0}};
  const StanleyResult result =
      StanleyController(makeConfig()).calculate(path, 0.0, 0.0, 1.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_TRUE(std::isfinite(result.steering_angle_rad));
}

TEST(StanleyController, OnePointPathIsInvalid) {
  const StanleyResult result = StanleyController(makeConfig()).calculate(
      std::vector<PathPoint>{{0.0, 0.0}}, 5.0, 0.0, 0.02);
  EXPECT_FALSE(result.valid);
}

TEST(StanleyController, DuplicateOnlyPathIsInvalid) {
  const StanleyResult result = StanleyController(makeConfig()).calculate(
      std::vector<PathPoint>{{0.0, 0.0}, {0.0, 0.0}}, 5.0, 0.0, 0.02);
  EXPECT_FALSE(result.valid);
}

TEST(StanleyController, PathWithoutTwoFinitePointsIsInvalid) {
  const double nan = std::numeric_limits<double>::quiet_NaN();
  const StanleyResult result = StanleyController(makeConfig()).calculate(
      std::vector<PathPoint>{{nan, 0.0}, {5.0, 0.0}}, 5.0, 0.0, 0.02);
  EXPECT_FALSE(result.valid);
}

TEST(StanleyController, NegativeSpeedIsInvalid) {
  const StanleyResult result = StanleyController(makeConfig()).calculate(
      std::vector<PathPoint>{{0.0, 0.0}, {5.0, 0.0}}, -0.1, 0.0, 0.02);
  EXPECT_FALSE(result.valid);
}

TEST(StanleyController, NonpositiveTimestepIsInvalid) {
  const std::vector<PathPoint> path{{0.0, 0.0}, {5.0, 0.0}};
  EXPECT_FALSE(
      StanleyController(makeConfig()).calculate(path, 5.0, 0.0, 0.0).valid);
  EXPECT_FALSE(
      StanleyController(makeConfig()).calculate(path, 5.0, 0.0, -0.02).valid);
}

TEST(StanleyController, InvalidConfigurationIsInvalid) {
  StanleyConfig config = makeConfig();
  config.gain = 0.0;
  const StanleyResult result = StanleyController(config).calculate(
      std::vector<PathPoint>{{0.0, 0.0}, {5.0, 0.0}}, 5.0, 0.0, 0.02);
  EXPECT_FALSE(result.valid);
}

}  // namespace
}  // namespace vehicle_control

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
