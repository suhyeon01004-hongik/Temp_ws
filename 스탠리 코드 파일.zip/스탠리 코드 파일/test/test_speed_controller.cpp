#include <gtest/gtest.h>

#include <limits>

#include "vehicle_control/speed_controller.hpp"

namespace vehicle_control {
namespace {

SpeedControllerConfig makeConfig() {
  return SpeedControllerConfig{0.1, 0.1, 0.5 / 3.6, 0.4, 0.6};
}

TEST(SpeedController, AcceleratesBelowTarget) {
  const PedalCommand result =
      SpeedController(makeConfig()).calculate(5.0, 6.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_GT(result.accelerator, 0.0);
  EXPECT_DOUBLE_EQ(0.0, result.brake);
}

TEST(SpeedController, BrakesAboveTarget) {
  const PedalCommand result =
      SpeedController(makeConfig()).calculate(6.0, 5.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_DOUBLE_EQ(0.0, result.accelerator);
  EXPECT_GT(result.brake, 0.0);
}

TEST(SpeedController, AppliesConfiguredProportionalGains) {
  const SpeedController controller(makeConfig());
  const PedalCommand accelerating = controller.calculate(5.0, 7.0);
  const PedalCommand braking = controller.calculate(7.0, 5.0);
  ASSERT_TRUE(accelerating.valid) << accelerating.error;
  ASSERT_TRUE(braking.valid) << braking.error;
  EXPECT_DOUBLE_EQ(0.2, accelerating.accelerator);
  EXPECT_DOUBLE_EQ(0.2, braking.brake);
}

TEST(SpeedController, ReturnsZeroPedalsInsideDeadband) {
  const PedalCommand result =
      SpeedController(makeConfig()).calculate(5.0, 5.1);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_DOUBLE_EQ(0.0, result.accelerator);
  EXPECT_DOUBLE_EQ(0.0, result.brake);
}

TEST(SpeedController, ClampsAcceleratorAtConfiguredMaximum) {
  const PedalCommand result =
      SpeedController(makeConfig()).calculate(0.0, 10.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_DOUBLE_EQ(0.4, result.accelerator);
  EXPECT_DOUBLE_EQ(0.0, result.brake);
}

TEST(SpeedController, ClampsBrakeAtConfiguredMaximum) {
  const PedalCommand result =
      SpeedController(makeConfig()).calculate(10.0, 0.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_DOUBLE_EQ(0.0, result.accelerator);
  EXPECT_DOUBLE_EQ(0.6, result.brake);
}

TEST(SpeedController, NeverCommandsBothPedals) {
  const SpeedController controller(makeConfig());
  const PedalCommand accelerating = controller.calculate(1.0, 2.0);
  const PedalCommand braking = controller.calculate(2.0, 1.0);
  const PedalCommand holding = controller.calculate(1.0, 1.0);
  ASSERT_TRUE(accelerating.valid) << accelerating.error;
  ASSERT_TRUE(braking.valid) << braking.error;
  ASSERT_TRUE(holding.valid) << holding.error;
  EXPECT_FALSE(accelerating.accelerator > 0.0 && accelerating.brake > 0.0);
  EXPECT_FALSE(braking.accelerator > 0.0 && braking.brake > 0.0);
  EXPECT_FALSE(holding.accelerator > 0.0 && holding.brake > 0.0);
}

TEST(SpeedController, RejectsNegativeOrNonfiniteSpeeds) {
  const double nan = std::numeric_limits<double>::quiet_NaN();
  const SpeedController controller(makeConfig());
  EXPECT_FALSE(controller.calculate(-0.1, 1.0).valid);
  EXPECT_FALSE(controller.calculate(1.0, -0.1).valid);
  EXPECT_FALSE(controller.calculate(nan, 1.0).valid);
  EXPECT_FALSE(controller.calculate(1.0, nan).valid);
}

TEST(SpeedController, RejectsInvalidConfiguration) {
  SpeedControllerConfig config = makeConfig();
  config.accelerator_gain = 0.0;
  EXPECT_FALSE(SpeedController(config).calculate(1.0, 2.0).valid);
}

}  // namespace
}  // namespace vehicle_control

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
