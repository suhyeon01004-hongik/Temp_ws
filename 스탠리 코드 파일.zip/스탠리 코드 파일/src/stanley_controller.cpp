#include "vehicle_control/stanley_controller.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <utility>
#include <vector>

namespace vehicle_control {
namespace {

constexpr double kPi = 3.14159265358979323846;

struct IndexedPathPoint {
  PathPoint point;
  std::size_t original_index;
};

double normalizeAngle(double angle_rad) {
  while (angle_rad > kPi) {
    angle_rad -= 2.0 * kPi;
  }
  while (angle_rad < -kPi) {
    angle_rad += 2.0 * kPi;
  }
  return angle_rad;
}

StanleyResult invalidResult(const std::string& error) {
  return StanleyResult{false, 0.0, 0.0, 0.0, 0.0, 0.0, 0U, error};
}

bool isPositiveFinite(double value) {
  return std::isfinite(value) && value > 0.0;
}

std::string configurationError(const StanleyConfig& config) {
  if (!isPositiveFinite(config.wheel_base_m)) {
    return "wheel base must be positive and finite";
  }
  if (!isPositiveFinite(config.gain)) {
    return "Stanley gain must be positive and finite";
  }
  if (!isPositiveFinite(config.softening_gain)) {
    return "softening gain must be positive and finite";
  }
  if (!isPositiveFinite(config.minimum_control_speed_mps)) {
    return "minimum control speed must be positive and finite";
  }
  if (!isPositiveFinite(config.maximum_steering_angle_rad)) {
    return "maximum steering angle must be positive and finite";
  }
  if (!isPositiveFinite(config.maximum_steering_rate_rad_per_sec)) {
    return "maximum steering rate must be positive and finite";
  }
  return std::string();
}

}  // namespace

StanleyController::StanleyController(const StanleyConfig& config)
    : config_(config),
      config_valid_(false),
      config_error_(configurationError(config)) {
  config_valid_ = config_error_.empty();
}

StanleyResult StanleyController::calculate(
    const std::vector<PathPoint>& path, double speed_mps,
    double previous_steering_angle_rad, double dt_sec) const {
  if (!config_valid_) {
    return invalidResult("invalid Stanley configuration: " + config_error_);
  }
  if (!std::isfinite(speed_mps) || speed_mps < 0.0) {
    return invalidResult("speed must be finite and nonnegative");
  }
  if (!std::isfinite(previous_steering_angle_rad)) {
    return invalidResult("previous steering angle must be finite");
  }
  if (!isPositiveFinite(dt_sec)) {
    return invalidResult("timestep must be positive and finite");
  }

  std::vector<IndexedPathPoint> finite_path;
  finite_path.reserve(path.size());
  for (std::size_t index = 0; index < path.size(); ++index) {
    if (std::isfinite(path[index].x) && std::isfinite(path[index].y)) {
      finite_path.push_back(IndexedPathPoint{path[index], index});
    }
  }
  if (finite_path.size() < 2U) {
    return invalidResult("path requires at least two finite points");
  }

  const double front_axle_x = config_.wheel_base_m;
  const double front_axle_y = 0.0;
  double nearest_distance = std::numeric_limits<double>::infinity();
  double target_x = 0.0;
  double target_y = 0.0;
  double path_yaw = 0.0;
  std::size_t target_segment_index = 0U;
  bool found_segment = false;

  for (std::size_t index = 0; index + 1U < finite_path.size(); ++index) {
    const PathPoint& start = finite_path[index].point;
    const PathPoint& end = finite_path[index + 1U].point;
    const double segment_x = end.x - start.x;
    const double segment_y = end.y - start.y;
    const double segment_length = std::hypot(segment_x, segment_y);
    if (!std::isfinite(segment_length) || segment_length <= 0.0) {
      continue;
    }

    const double start_to_axle_x = front_axle_x - start.x;
    const double start_to_axle_y = front_axle_y - start.y;
    const double projection =
        (start_to_axle_x * segment_x + start_to_axle_y * segment_y) /
        (segment_length * segment_length);
    const double clamped_projection = std::max(0.0, std::min(1.0, projection));
    const double candidate_x = start.x + clamped_projection * segment_x;
    const double candidate_y = start.y + clamped_projection * segment_y;
    const double distance =
        std::hypot(candidate_x - front_axle_x, candidate_y - front_axle_y);

    if (std::isfinite(distance) && distance < nearest_distance) {
      nearest_distance = distance;
      target_x = candidate_x;
      target_y = candidate_y;
      path_yaw = std::atan2(segment_y, segment_x);
      target_segment_index = finite_path[index].original_index;
      found_segment = true;
    }
  }

  if (!found_segment) {
    return invalidResult("path requires a nonzero-length segment");
  }

  const double left_normal_x = -std::sin(path_yaw);
  const double left_normal_y = std::cos(path_yaw);
  const double cross_track_error =
      left_normal_x * (target_x - front_axle_x) +
      left_normal_y * (target_y - front_axle_y);
  const double heading_error = normalizeAngle(path_yaw);
  const double control_speed =
      std::max(speed_mps, config_.minimum_control_speed_mps);
  const double requested_steering =
      heading_error + std::atan2(config_.gain * cross_track_error,
                                 control_speed + config_.softening_gain);
  const double saturated_steering =
      std::max(-config_.maximum_steering_angle_rad,
               std::min(config_.maximum_steering_angle_rad,
                        requested_steering));
  const double maximum_change = config_.maximum_steering_rate_rad_per_sec * dt_sec;
  const double rate_limited_steering =
      std::max(previous_steering_angle_rad - maximum_change,
               std::min(previous_steering_angle_rad + maximum_change,
                        saturated_steering));
  const double steering_angle =
      std::max(-config_.maximum_steering_angle_rad,
               std::min(config_.maximum_steering_angle_rad,
                        rate_limited_steering));

  if (!std::isfinite(cross_track_error) || !std::isfinite(heading_error) ||
      !std::isfinite(target_x) || !std::isfinite(target_y) ||
      !std::isfinite(steering_angle)) {
    return invalidResult("Stanley calculation produced a nonfinite result");
  }

  return StanleyResult{true, steering_angle, cross_track_error, heading_error,
                       target_x, target_y, target_segment_index, std::string()};
}

}  // namespace vehicle_control
