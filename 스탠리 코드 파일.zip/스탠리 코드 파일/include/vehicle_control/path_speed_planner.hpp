#pragma once

#include <string>
#include <vector>

#include "vehicle_control/path_point.hpp"

namespace vehicle_control {

struct PathSpeedConfig {
  double maximum_speed_mps;
  double minimum_curve_speed_mps;
  double maximum_lateral_acceleration_mps2;
  double maximum_longitudinal_deceleration_mps2;
  double origin_projection_ambiguity_tolerance_m;
  double curvature_epsilon;
  double evaluation_start_m;
  double evaluation_end_m;
  double heading_error_slowdown_gain;
  double cross_track_error_slowdown_gain;
  double target_speed_rise_mps2;
  double target_speed_fall_mps2;
};

struct PathSpeedResult {
  bool valid;
  double target_speed_mps;
  double representative_curvature;
  std::string error;
};

class PathSpeedPlanner {
 public:
  explicit PathSpeedPlanner(const PathSpeedConfig& config);

  PathSpeedResult calculate(const std::vector<PathPoint>& path,
                            double heading_error_rad,
                            double cross_track_error_m,
                            double previous_target_speed_mps,
                            double dt_sec) const;

 private:
  PathSpeedConfig config_;
  bool config_valid_;
  std::string config_error_;
};

}  // namespace vehicle_control
