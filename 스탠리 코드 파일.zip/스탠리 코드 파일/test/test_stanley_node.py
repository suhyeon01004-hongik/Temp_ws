#!/usr/bin/env python3

import math
import threading
import time
import unittest

import rospy
import rostest
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry, Path
from std_msgs.msg import Float32
from vehicle_control.msg import VehicleCommand


class StanleyNodeTest(unittest.TestCase):
    _PRIVATE_NAMESPACE = "/stanley_node_test/stanley_node"

    def setUp(self):
        self._condition = threading.Condition()
        self._commands = []
        self._target_speeds = []
        self._command_events = []
        self._target_speed_events = []
        self._command_subscriber = rospy.Subscriber(
            "/test/stanley/command",
            VehicleCommand,
            self._on_command,
            queue_size=50,
        )
        self._target_speed_subscriber = rospy.Subscriber(
            "/test/stanley/target_speed_kph",
            Float32,
            self._on_target_speed,
            queue_size=50,
        )
        self._path_publisher = rospy.Publisher(
            "/test/stanley/path",
            Path,
            queue_size=10,
        )
        self._odometry_publisher = rospy.Publisher(
            "/test/stanley/odometry",
            Odometry,
            queue_size=10,
        )

        deadline = time.monotonic() + 3.0
        while (
            self._path_publisher.get_num_connections() == 0
            or self._odometry_publisher.get_num_connections() == 0
            or self._command_subscriber.get_num_connections() == 0
            or self._target_speed_subscriber.get_num_connections() == 0
        ):
            if time.monotonic() >= deadline:
                self.fail("Stanley node test topics were not ready")
            rospy.sleep(0.01)

    def tearDown(self):
        self._command_subscriber.unregister()
        self._target_speed_subscriber.unregister()
        self._path_publisher.unregister()
        self._odometry_publisher.unregister()

    def _on_command(self, command):
        with self._condition:
            self._commands.append(command)
            self._command_events.append((time.monotonic(), command))
            self._condition.notify_all()

    def _on_target_speed(self, speed):
        with self._condition:
            self._target_speeds.append(speed.data)
            self._target_speed_events.append(
                (time.monotonic(), speed.data)
            )
            self._condition.notify_all()

    @staticmethod
    def _path(frame_id="base_link", lateral_offset_m=0.0):
        message = Path()
        message.header.frame_id = frame_id
        for index in range(20):
            pose = PoseStamped()
            pose.pose.position.x = 0.5 * index
            pose.pose.position.y = lateral_offset_m
            message.poses.append(pose)
        return message

    @staticmethod
    def _odometry():
        message = Odometry()
        message.twist.twist.linear.x = 0.0
        message.twist.twist.linear.y = 0.0
        return message

    def _publish_for(self, duration, path=None, odometry=None):
        deadline = time.monotonic() + duration
        while time.monotonic() < deadline and not rospy.is_shutdown():
            stamp = rospy.Time.now()
            if path is not None:
                path.header.stamp = stamp
                self._path_publisher.publish(path)
            if odometry is not None:
                odometry.header.stamp = stamp
                self._odometry_publisher.publish(odometry)
            rospy.sleep(0.01)

    def _snapshot(self):
        with self._condition:
            return len(self._commands), len(self._target_speeds)

    def _sample_phase_outputs(
        self,
        transition_duration,
        sample_duration,
        path,
        odometry,
    ):
        self._publish_for(
            transition_duration,
            path=path,
            odometry=odometry,
        )
        command_start, speed_start = self._snapshot()
        self._publish_for(
            sample_duration,
            path=path,
            odometry=odometry,
        )

        minimum_messages = 3
        deadline = time.monotonic() + 1.0
        with self._condition:
            while (
                (
                    len(self._commands) - command_start < minimum_messages
                    or len(self._target_speeds) - speed_start
                    < minimum_messages
                )
                and time.monotonic() < deadline
                and not rospy.is_shutdown()
            ):
                self._condition.wait(timeout=0.05)

            commands = list(self._commands[command_start:])
            speeds = list(self._target_speeds[speed_start:])

        self.assertGreaterEqual(
            len(commands),
            minimum_messages,
            "phase produced too few command samples",
        )
        self.assertGreaterEqual(
            len(speeds),
            minimum_messages,
            "phase produced too few target-speed samples",
        )
        return commands, speeds

    def _assert_phase_outputs(
        self,
        transition_duration,
        sample_duration,
        path,
        odometry,
        command_matches,
        speed_matches,
    ):
        commands, speeds = self._sample_phase_outputs(
            transition_duration,
            sample_duration,
            path,
            odometry,
        )
        self.assertTrue(
            all(command_matches(command) for command in commands),
            "phase included a command from the wrong control behavior",
        )
        self.assertTrue(
            all(speed_matches(speed) for speed in speeds),
            "phase included a target speed from the wrong control behavior",
        )
        return commands[-1], speeds[-1]

    def _first_recovery_outputs(self, path, odometry):
        with self._condition:
            command_start = len(self._command_events)
            speed_start = len(self._target_speed_events)
            last_safe_event = next(
                (
                    event
                    for event in reversed(self._command_events)
                    if self._is_safe_command(event[1])
                ),
                None,
            )
        self.assertIsNotNone(
            last_safe_event,
            "recovery test had no preceding safe command",
        )
        self._publish_for(0.12, path=path, odometry=odometry)

        deadline = time.monotonic() + 1.0
        with self._condition:
            while (
                (
                    not any(
                        math.isclose(command.brake, 0.0, abs_tol=1e-6)
                        for _, command in self._command_events[command_start:]
                    )
                    or not any(
                        speed > 0.0
                        for _, speed
                        in self._target_speed_events[speed_start:]
                    )
                )
                and time.monotonic() < deadline
                and not rospy.is_shutdown()
            ):
                self._condition.wait(timeout=0.05)

            command_events = list(
                self._command_events[command_start:]
            )
            speed_events = list(
                self._target_speed_events[speed_start:]
            )

        first_drive_event = next(
            (
                event
                for event in command_events
                if math.isclose(
                    event[1].brake, 0.0, abs_tol=1e-6
                )
            ),
            None,
        )
        first_positive_speed_event = next(
            (event for event in speed_events if event[1] > 0.0),
            None,
        )
        self.assertIsNotNone(
            first_drive_event,
            "recovery produced no drive command",
        )
        self.assertIsNotNone(
            first_positive_speed_event,
            "recovery produced no positive target speed",
        )
        self.assertLessEqual(
            abs(
                first_drive_event[0]
                - first_positive_speed_event[0]
            ),
            0.05,
            "first recovery command and target were not a paired cycle",
        )
        recovery_dt = (
            first_drive_event[1].header.stamp
            - last_safe_event[1].header.stamp
        ).to_sec()
        self.assertGreater(recovery_dt, 0.0)
        self.assertLessEqual(
            recovery_dt,
            0.25,
            "recovery timer gap was too long to verify slew limits",
        )
        return (
            first_drive_event[1],
            first_positive_speed_event[1],
            recovery_dt,
        )

    @staticmethod
    def _is_safe_command(command):
        return (
            command.gear == VehicleCommand.GEAR_DRIVE
            and math.isclose(command.accel, 0.0, abs_tol=1e-6)
            and math.isclose(command.brake, 0.5, abs_tol=1e-6)
            and math.isclose(command.steering, 0.0, abs_tol=1e-6)
        )

    def test_configuration_is_loaded_into_private_namespace(self):
        expected_parameters = {
            "wheel_base_m": 3.0,
            "maximum_steering_angle_deg": 40.0,
            "maximum_speed_kph": 60.0,
            "maximum_longitudinal_deceleration_mps2": 2.0,
            "origin_projection_ambiguity_tolerance_m": 0.05,
            "expected_path_points": 20,
            "expected_path_spacing_m": 0.5,
        }
        for name, expected in expected_parameters.items():
            parameter = "{}/{}".format(self._PRIVATE_NAMESPACE, name)
            self.assertTrue(
                rospy.has_param(parameter),
                "{} was not loaded".format(parameter),
            )
            self.assertEqual(rospy.get_param(parameter), expected)

    def test_tracks_valid_path_and_fails_safe_for_invalid_inputs(self):
        odometry = self._odometry()
        centered_command = lambda value: (
            value.gear == VehicleCommand.GEAR_DRIVE
            and value.accel > 0.0
            and math.isclose(value.brake, 0.0, abs_tol=1e-6)
            and math.isclose(value.steering, 0.0, abs_tol=1e-3)
        )
        valid_drive_command = lambda value: (
            value.gear == VehicleCommand.GEAR_DRIVE
            and value.accel > 0.0
            and math.isclose(value.brake, 0.0, abs_tol=1e-6)
            and math.isfinite(value.steering)
            and -1.0 <= value.steering <= 1.0
        )
        positive_target = (
            lambda value: math.isfinite(value) and value > 0.0
        )
        zero_target = (
            lambda value: math.isclose(value, 0.0, abs_tol=1e-6)
        )

        self._assert_phase_outputs(
            0.15,
            0.15,
            self._path(frame_id="/base_link"),
            odometry,
            centered_command,
            positive_target,
        )

        self._assert_phase_outputs(
            0.10,
            0.15,
            self._path(lateral_offset_m=1.0),
            odometry,
            lambda value: value.steering > 0.0,
            positive_target,
        )

        self._assert_phase_outputs(
            0.22,
            0.15,
            None,
            odometry,
            self._is_safe_command,
            zero_target,
        )

        (
            recovery_command,
            recovery_speed,
            recovery_dt,
        ) = self._first_recovery_outputs(
            self._path(lateral_offset_m=1.0),
            odometry,
        )
        steering_limit = (
            120.0 / 40.0 * recovery_dt + 0.02
        )
        speed_limit_kph = 5.0 * recovery_dt + 0.05
        self.assertGreater(recovery_command.steering, 0.0)
        self.assertLessEqual(
            recovery_command.steering,
            steering_limit,
            "first recovered steering was not rate-limited from zero",
        )
        self.assertGreater(recovery_speed, 0.0)
        self.assertLessEqual(
            recovery_speed,
            speed_limit_kph,
            "first recovered target speed did not rise from zero",
        )

        self._assert_phase_outputs(
            0.10,
            0.15,
            self._path(),
            odometry,
            valid_drive_command,
            positive_target,
        )
        self._assert_phase_outputs(
            0.10,
            0.15,
            self._path(frame_id="map"),
            odometry,
            self._is_safe_command,
            zero_target,
        )

        self._assert_phase_outputs(
            0.15,
            0.15,
            self._path(),
            odometry,
            valid_drive_command,
            positive_target,
        )
        mixed_nan_path = self._path()
        mixed_nan_path.poses[7].pose.position.x = float("nan")
        self._assert_phase_outputs(
            0.10,
            0.15,
            mixed_nan_path,
            odometry,
            self._is_safe_command,
            zero_target,
        )

        self._assert_phase_outputs(
            0.15,
            0.15,
            self._path(),
            odometry,
            valid_drive_command,
            positive_target,
        )
        mixed_infinite_path = self._path()
        mixed_infinite_path.poses[12].pose.position.y = float("inf")
        self._assert_phase_outputs(
            0.10,
            0.15,
            mixed_infinite_path,
            odometry,
            self._is_safe_command,
            zero_target,
        )

        self._assert_phase_outputs(
            0.15,
            0.15,
            self._path(),
            odometry,
            valid_drive_command,
            positive_target,
        )
        self._assert_phase_outputs(
            0.25,
            0.15,
            self._path(),
            None,
            self._is_safe_command,
            zero_target,
        )


if __name__ == "__main__":
    rospy.init_node("test_stanley_node")
    rostest.rosrun("vehicle_control", "stanley_node", StanleyNodeTest)
