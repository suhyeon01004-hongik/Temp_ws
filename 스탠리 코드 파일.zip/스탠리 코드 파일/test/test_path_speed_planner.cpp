#include <gtest/gtest.h>

#include <cmath>
#include <limits>
#include <vector>

#include "vehicle_control/path_point.hpp"
#include "vehicle_control/path_speed_planner.hpp"

namespace vehicle_control {
namespace {

constexpr double kMaximumSpeedMps = 60.0 / 3.6;
constexpr double kMinimumSpeedMps = 5.0 / 3.6;
constexpr double kRiseLimitMps2 = 5.0 / 3.6;
constexpr double kFallLimitMps2 = 20.0 / 3.6;
constexpr double kPlanningDecelerationMps2 = 2.0;
constexpr double kOriginProjectionAmbiguityToleranceM = 0.05;

PathSpeedConfig makeSpeedConfig() {
  return PathSpeedConfig{
      kMaximumSpeedMps, kMinimumSpeedMps, 2.5,
      kPlanningDecelerationMps2, kOriginProjectionAmbiguityToleranceM,
      1e-6, 2.0, 8.0, 1.0, 1.0, kRiseLimitMps2, kFallLimitMps2};
}

std::vector<PathPoint> shortStraightPath() {
  std::vector<PathPoint> path;
  for (int index = 0; index < 20; ++index) {
    path.push_back(PathPoint{0.5 * index, 0.0});
  }
  return path;
}

std::vector<PathPoint> longStraightPath() {
  return std::vector<PathPoint>{{0.0, 0.0},  {20.0, 0.0},
                                {40.0, 0.0}, {60.0, 0.0},
                                {80.0, 0.0}};
}

TEST(PathSpeedPlanner, ShortStraightDropsImmediatelyToVisibilityCeiling) {
  const std::vector<PathPoint> path = shortStraightPath();
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(path, 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  ASSERT_TRUE(result.valid) << result.error;
  const double expected =
      std::sqrt(kMinimumSpeedMps * kMinimumSpeedMps +
                2.0 * kPlanningDecelerationMps2 * 9.5);
  EXPECT_NEAR(expected, result.target_speed_mps, 1e-9);
  EXPECT_NEAR(0.0, result.representative_curvature, 1e-9);
}

TEST(PathSpeedPlanner, LongStraightCanRetainSixtyKph) {
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(longStraightPath(), 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(kMaximumSpeedMps, result.target_speed_mps, 1e-9);
  EXPECT_NEAR(0.0, result.representative_curvature, 1e-9);
}

TEST(PathSpeedPlanner, SuddenCurveHardCapDefeatsFallRateLimit) {
  const std::vector<PathPoint> curve{{0.0, 0.0}, {2.0, 0.0},
                                     {4.0, 0.0}, {4.0, 2.0},
                                     {4.0, 4.0}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(curve, 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  ASSERT_TRUE(result.valid) << result.error;
  const double sample_curvature = 1.0 / std::sqrt(2.0);
  const double curve_speed = std::sqrt(2.5 / sample_curvature);
  const double expected =
      std::sqrt(curve_speed * curve_speed +
                2.0 * kPlanningDecelerationMps2 * 4.0);
  EXPECT_NEAR(expected, result.target_speed_mps, 1e-9);
  EXPECT_LT(result.target_speed_mps,
            kMaximumSpeedMps - kFallLimitMps2 * 0.02);
}

TEST(PathSpeedPlanner, PrependedBehindSegmentPreservesCurveDistance) {
  const std::vector<PathPoint> from_origin{
      {0.0, 0.0}, {2.0, 0.0}, {4.0, 0.0},
      {4.0, 2.0}, {4.0, 4.0}};
  const std::vector<PathPoint> with_behind_segment{
      {-4.0, 0.0}, {-2.0, 0.0}, {0.0, 0.0}, {2.0, 0.0},
      {4.0, 0.0},  {4.0, 2.0},  {4.0, 4.0}};
  const PathSpeedPlanner planner(makeSpeedConfig());
  const PathSpeedResult origin_result = planner.calculate(
      from_origin, 0.0, 0.0, kMaximumSpeedMps, 0.02);
  const PathSpeedResult prepended_result = planner.calculate(
      with_behind_segment, 0.0, 0.0, kMaximumSpeedMps, 0.02);
  ASSERT_TRUE(origin_result.valid) << origin_result.error;
  ASSERT_TRUE(prepended_result.valid) << prepended_result.error;
  EXPECT_NEAR(origin_result.target_speed_mps,
              prepended_result.target_speed_mps, 1e-9);
}

TEST(PathSpeedPlanner, CurvatureStrictlyBehindVehicleDoesNotHardCapSpeed) {
  const std::vector<PathPoint> path{
      {-6.0, 2.0}, {-4.0, 2.0}, {-2.0, 0.0},
      {0.0, 0.0},  {2.0, 0.0},  {4.0, 0.0},
      {20.0, 0.0}, {40.0, 0.0}, {80.0, 0.0}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(path, 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(kMaximumSpeedMps, result.target_speed_mps, 1e-9);
  EXPECT_NEAR(0.0, result.representative_curvature, 1e-9);
}

TEST(PathSpeedPlanner, BehindOnlyCurvatureDoesNotAffectComfortTarget) {
  const std::vector<PathPoint> path{
      {-4.0, 2.0}, {-2.0, 0.0}, {-1.0, 0.0}, {100.0, 0.0}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(path, 0.0, 0.0,
                                                kMaximumSpeedMps, 10.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(kMaximumSpeedMps, result.target_speed_mps, 1e-9);
  EXPECT_NEAR(0.0, result.representative_curvature, 1e-9);
}

TEST(PathSpeedPlanner, VehicleProjectionAtPathEndHasZeroHorizon) {
  const std::vector<PathPoint> behind_path{
      {-6.0, 0.0}, {-4.0, 0.0}, {-2.0, 0.0}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(behind_path, 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(kMinimumSpeedMps, result.target_speed_mps, 1e-9);
}

TEST(PathSpeedPlanner, MateriallySeparatedExactOriginProjectionsAreInvalid) {
  const std::vector<PathPoint> looping_path{
      {-2.0, 0.0}, {0.0, 0.0}, {2.0, 0.0}, {0.0, 0.0}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(looping_path, 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  EXPECT_FALSE(result.valid);
  EXPECT_EQ("path origin projection is ambiguous", result.error);
}

TEST(PathSpeedPlanner, MateriallySeparatedNearOriginProjectionsAreInvalid) {
  const std::vector<PathPoint> near_crossing_path{
      {-2.0, 0.0}, {2.0, 0.0},  {2.0, 1.0},
      {-2.0, 1.0}, {-2.0, 0.04}, {2.0, 0.04}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(near_crossing_path, 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  EXPECT_FALSE(result.valid);
  EXPECT_EQ("path origin projection is ambiguous", result.error);
}

TEST(PathSpeedPlanner, SharedVertexProjectionCandidatesRemainValid) {
  const std::vector<PathPoint> path{
      {-2.0, 0.0}, {0.0, 0.0}, {0.0, 2.0}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(path, 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_TRUE(std::isfinite(result.target_speed_mps));
}

TEST(PathSpeedPlanner, UniqueOriginProjectionRemainsValid) {
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(longStraightPath(), 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  ASSERT_TRUE(result.valid) << result.error;
}

TEST(PathSpeedPlanner, PathBeginningAheadUsesClampedStartProjection) {
  const std::vector<PathPoint> ahead_path{{2.0, 0.0}, {4.0, 0.0}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(ahead_path, 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  ASSERT_TRUE(result.valid) << result.error;
  const double expected =
      std::sqrt(kMinimumSpeedMps * kMinimumSpeedMps +
                2.0 * kPlanningDecelerationMps2 * 2.0);
  EXPECT_NEAR(expected, result.target_speed_mps, 1e-9);
}

TEST(PathSpeedPlanner, LargeFiniteProjectionAvoidsSquaredOverflow) {
  const std::vector<PathPoint> path{
      {1e154, 0.0}, {0.0, 1e154}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(path, 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_TRUE(std::isfinite(result.target_speed_mps));
}

TEST(PathSpeedPlanner, ProjectionIntermediateOverflowIsInvalid) {
  const std::vector<PathPoint> path{
      {1.3e308, 1.3e308}, {1.4e308, 1.4e308}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(path, 0.0, 0.0,
                                                kMaximumSpeedMps, 0.02);
  EXPECT_FALSE(result.valid);
}

TEST(PathSpeedPlanner, CurvedPathProducesFiniteConservativeSpeed) {
  const std::vector<PathPoint> curve{{0.0, 0.0},  {2.0, 0.2},
                                     {4.0, 0.8},  {6.0, 1.8},
                                     {8.0, 3.2},  {10.0, 5.0}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(curve, 0.0, 0.0,
                                                kMaximumSpeedMps, 1.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_GT(result.representative_curvature, 0.0);
  EXPECT_LT(result.target_speed_mps, kMaximumSpeedMps);
  EXPECT_GE(result.target_speed_mps, kMinimumSpeedMps);
}

TEST(PathSpeedPlanner, HeadingErrorReducesTargetSpeed) {
  const std::vector<PathPoint> path = longStraightPath();
  const PathSpeedPlanner planner(makeSpeedConfig());
  const PathSpeedResult centered =
      planner.calculate(path, 0.0, 0.0, kMaximumSpeedMps, 1.0);
  const PathSpeedResult misaligned =
      planner.calculate(path, 1.0, 0.0, kMaximumSpeedMps, 1.0);
  ASSERT_TRUE(centered.valid) << centered.error;
  ASSERT_TRUE(misaligned.valid) << misaligned.error;
  EXPECT_LT(misaligned.target_speed_mps, centered.target_speed_mps);
}

TEST(PathSpeedPlanner, CrossTrackErrorReducesTargetSpeed) {
  const std::vector<PathPoint> path = longStraightPath();
  const PathSpeedPlanner planner(makeSpeedConfig());
  const PathSpeedResult centered =
      planner.calculate(path, 0.0, 0.0, kMaximumSpeedMps, 1.0);
  const PathSpeedResult displaced =
      planner.calculate(path, 0.0, 1.0, kMaximumSpeedMps, 1.0);
  ASSERT_TRUE(centered.valid) << centered.error;
  ASSERT_TRUE(displaced.valid) << displaced.error;
  EXPECT_LT(displaced.target_speed_mps, centered.target_speed_mps);
}

TEST(PathSpeedPlanner, RiseLimitIsFiveKphPerSecond) {
  const std::vector<PathPoint> path = longStraightPath();
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(path, 0.0, 0.0,
                                                kMinimumSpeedMps, 1.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(kMinimumSpeedMps + kRiseLimitMps2, result.target_speed_mps,
              1e-9);
}

TEST(PathSpeedPlanner, RiseFromZeroCanRemainBelowSteadyMinimum) {
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(longStraightPath(), 0.0, 0.0,
                                                0.0, 0.1);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(kRiseLimitMps2 * 0.1, result.target_speed_mps, 1e-9);
  EXPECT_LT(result.target_speed_mps, kMinimumSpeedMps);
}

TEST(PathSpeedPlanner, FallLimitIsTwentyKphPerSecond) {
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(longStraightPath(), 1.0, 0.0,
                                                kMaximumSpeedMps, 1.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(kMaximumSpeedMps - kFallLimitMps2, result.target_speed_mps,
              1e-9);
}

TEST(PathSpeedPlanner, ValidTrackingSpeedStaysWithinConfiguredBounds) {
  const std::vector<PathPoint> curve{{0.0, 0.0}, {1.0, 0.0},
                                     {1.0, 1.0}, {1.0, 2.0}};
  const PathSpeedPlanner planner(makeSpeedConfig());
  const PathSpeedResult low_previous = planner.calculate(curve, 0.0, 0.0,
                                                         kMinimumSpeedMps, 1.0);
  const PathSpeedResult high_previous = planner.calculate(
      longStraightPath(), 0.0, 0.0, kMaximumSpeedMps, 1.0);
  ASSERT_TRUE(low_previous.valid) << low_previous.error;
  ASSERT_TRUE(high_previous.valid) << high_previous.error;
  EXPECT_GE(low_previous.target_speed_mps, kMinimumSpeedMps);
  EXPECT_LE(low_previous.target_speed_mps, kMaximumSpeedMps);
  EXPECT_GE(high_previous.target_speed_mps, kMinimumSpeedMps);
  EXPECT_LE(high_previous.target_speed_mps, kMaximumSpeedMps);
}

TEST(PathSpeedPlanner, PreviousTargetOutsideConfiguredRangeIsInvalid) {
  const std::vector<PathPoint> path = longStraightPath();
  const PathSpeedPlanner planner(makeSpeedConfig());
  EXPECT_FALSE(
      planner.calculate(path, 0.0, 0.0, -0.1, 1.0).valid);
  EXPECT_TRUE(
      planner.calculate(path, 0.0, 0.0, kMinimumSpeedMps - 0.1, 1.0).valid);
  EXPECT_FALSE(
      planner.calculate(path, 0.0, 0.0, kMaximumSpeedMps + 0.1, 1.0).valid);
}

TEST(PathSpeedPlanner, DuplicateTripletsDoNotDivideByZero) {
  const std::vector<PathPoint> path{{0.0, 0.0}, {0.0, 0.0},
                                    {2.0, 0.0}, {4.0, 0.0},
                                    {4.0, 0.0}, {6.0, 0.0}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(path, 0.0, 0.0,
                                                kMaximumSpeedMps, 1.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_TRUE(std::isfinite(result.representative_curvature));
  EXPECT_TRUE(std::isfinite(result.target_speed_mps));
}

TEST(PathSpeedPlanner, TwoFiniteDistinctPointsHaveZeroCurvature) {
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(
                                         std::vector<PathPoint>{{0.0, 0.0},
                                                                {5.0, 0.0}},
                                         0.0, 0.0, kMaximumSpeedMps, 1.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(0.0, result.representative_curvature, 1e-9);
}

TEST(PathSpeedPlanner, OverflowingPathDistanceIsInvalid) {
  const double maximum = std::numeric_limits<double>::max();
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(
                                         std::vector<PathPoint>{{maximum, 0.0},
                                                                {-maximum, 0.0}},
                                         0.0, 0.0, kMaximumSpeedMps, 1.0);
  EXPECT_FALSE(result.valid);
}

TEST(PathSpeedPlanner, EvaluationWindowUsesOnlyCentersFromTwoToEightMeters) {
  const std::vector<PathPoint> path{{0.0, 0.0}, {1.0, 0.0},
                                    {2.0, 1.0}, {3.0, 2.0},
                                    {4.0, 3.0}, {5.0, 4.0},
                                    {6.0, 5.0}};
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(path, 0.0, 0.0,
                                                kMaximumSpeedMps, 1.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(0.0, result.representative_curvature, 1e-9);
}

TEST(PathSpeedPlanner, CurvatureFallbackUsesPercentileAndMaximumRule) {
  PathSpeedConfig config = makeSpeedConfig();
  config.evaluation_start_m = 100.0;
  config.evaluation_end_m = 101.0;
  const std::vector<PathPoint> path{{0.0, 0.0}, {1.0, 0.0},
                                    {2.0, 1.0}, {3.0, 2.0},
                                    {4.0, 3.0}, {5.0, 4.0},
                                    {6.0, 5.0}};
  const PathSpeedResult result = PathSpeedPlanner(config).calculate(
      path, 0.0, 0.0, kMaximumSpeedMps, 1.0);
  ASSERT_TRUE(result.valid) << result.error;
  EXPECT_NEAR(0.8 * 2.0 / std::sqrt(10.0),
              result.representative_curvature, 1e-9);
}

TEST(PathSpeedPlanner, FewerThanTwoFiniteDistinctPointsIsInvalid) {
  const PathSpeedResult result = PathSpeedPlanner(makeSpeedConfig())
                                     .calculate(
                                         std::vector<PathPoint>{{0.0, 0.0},
                                                                {0.0, 0.0}},
                                         0.0, 0.0, kMaximumSpeedMps, 1.0);
  EXPECT_FALSE(result.valid);
}

TEST(PathSpeedPlanner, NaNInputsAreInvalid) {
  const double nan = std::numeric_limits<double>::quiet_NaN();
  const std::vector<PathPoint> path{{0.0, 0.0}, {5.0, 0.0}};
  const PathSpeedPlanner planner(makeSpeedConfig());
  EXPECT_FALSE(planner.calculate(path, nan, 0.0, kMaximumSpeedMps, 1.0).valid);
  EXPECT_FALSE(planner.calculate(path, 0.0, nan, kMaximumSpeedMps, 1.0).valid);
  EXPECT_FALSE(planner.calculate(path, 0.0, 0.0, nan, 1.0).valid);
  EXPECT_FALSE(planner.calculate(path, 0.0, 0.0, kMaximumSpeedMps, nan).valid);
  EXPECT_FALSE(planner
                   .calculate(std::vector<PathPoint>{{0.0, 0.0}, {nan, 0.0}},
                              0.0, 0.0, kMaximumSpeedMps, 1.0)
                   .valid);
}

TEST(PathSpeedPlanner, InvalidConfigurationIsInvalid) {
  PathSpeedConfig config = makeSpeedConfig();
  config.maximum_lateral_acceleration_mps2 = 0.0;
  const PathSpeedResult result = PathSpeedPlanner(config).calculate(
      std::vector<PathPoint>{{0.0, 0.0}, {5.0, 0.0}}, 0.0, 0.0,
      kMaximumSpeedMps, 1.0);
  EXPECT_FALSE(result.valid);
}

TEST(PathSpeedPlanner, InvalidPlanningDecelerationIsInvalid) {
  PathSpeedConfig config = makeSpeedConfig();
  config.maximum_longitudinal_deceleration_mps2 = 0.0;
  const PathSpeedResult zero = PathSpeedPlanner(config).calculate(
      longStraightPath(), 0.0, 0.0, kMaximumSpeedMps, 1.0);
  config.maximum_longitudinal_deceleration_mps2 =
      std::numeric_limits<double>::infinity();
  const PathSpeedResult infinite = PathSpeedPlanner(config).calculate(
      longStraightPath(), 0.0, 0.0, kMaximumSpeedMps, 1.0);
  EXPECT_FALSE(zero.valid);
  EXPECT_FALSE(infinite.valid);
}

TEST(PathSpeedPlanner, InvalidOriginProjectionAmbiguityToleranceIsInvalid) {
  PathSpeedConfig config = makeSpeedConfig();
  config.origin_projection_ambiguity_tolerance_m = -0.01;
  const PathSpeedResult negative = PathSpeedPlanner(config).calculate(
      longStraightPath(), 0.0, 0.0, kMaximumSpeedMps, 1.0);
  config.origin_projection_ambiguity_tolerance_m =
      std::numeric_limits<double>::infinity();
  const PathSpeedResult infinite = PathSpeedPlanner(config).calculate(
      longStraightPath(), 0.0, 0.0, kMaximumSpeedMps, 1.0);
  config.origin_projection_ambiguity_tolerance_m =
      std::numeric_limits<double>::quiet_NaN();
  const PathSpeedResult nan = PathSpeedPlanner(config).calculate(
      longStraightPath(), 0.0, 0.0, kMaximumSpeedMps, 1.0);
  EXPECT_FALSE(negative.valid);
  EXPECT_FALSE(infinite.valid);
  EXPECT_FALSE(nan.valid);
}

TEST(PathSpeedPlanner, OriginProjectionAmbiguityLimitOverflowIsInvalid) {
  PathSpeedConfig config = makeSpeedConfig();
  config.origin_projection_ambiguity_tolerance_m =
      std::numeric_limits<double>::max();
  const PathSpeedResult result = PathSpeedPlanner(config).calculate(
      std::vector<PathPoint>{{1e308, 0.0}, {1e308, 1.0}},
      0.0, 0.0, kMaximumSpeedMps, 1.0);
  EXPECT_FALSE(result.valid);
}

TEST(PathSpeedPlanner, SafetyCeilingOverflowIsInvalid) {
  PathSpeedConfig config = makeSpeedConfig();
  config.maximum_longitudinal_deceleration_mps2 =
      std::numeric_limits<double>::max();
  const PathSpeedResult result = PathSpeedPlanner(config).calculate(
      std::vector<PathPoint>{{0.0, 0.0}, {5.0, 0.0}},
      0.0, 0.0, kMaximumSpeedMps, 1.0);
  EXPECT_FALSE(result.valid);
}

TEST(PathSpeedPlanner, SlowdownIntermediateOverflowIsInvalid) {
  const double maximum = std::numeric_limits<double>::max();
  PathSpeedConfig config = makeSpeedConfig();
  config.heading_error_slowdown_gain = 2.0;
  const PathSpeedResult heading = PathSpeedPlanner(config).calculate(
      longStraightPath(), maximum, 0.0, kMaximumSpeedMps, 1.0);
  config = makeSpeedConfig();
  config.cross_track_error_slowdown_gain = 2.0;
  const PathSpeedResult cross_track = PathSpeedPlanner(config).calculate(
      longStraightPath(), 0.0, maximum, kMaximumSpeedMps, 1.0);
  EXPECT_FALSE(heading.valid);
  EXPECT_FALSE(cross_track.valid);
}

TEST(PathSpeedPlanner, RateLimitSumOverflowIsInvalid) {
  const double maximum = std::numeric_limits<double>::max();
  PathSpeedConfig config = makeSpeedConfig();
  config.maximum_speed_mps = maximum;
  config.target_speed_rise_mps2 = maximum;
  const PathSpeedResult result = PathSpeedPlanner(config).calculate(
      longStraightPath(), 0.0, 0.0, maximum, 1.0);
  EXPECT_FALSE(result.valid);
}

TEST(PathSpeedPlanner, SampleCurveSpeedOverflowIsInvalid) {
  const double maximum = std::numeric_limits<double>::max();
  PathSpeedConfig config = makeSpeedConfig();
  config.maximum_lateral_acceleration_mps2 = maximum;
  const std::vector<PathPoint> path{{0.0, 0.0}, {1.0, 0.0},
                                    {2.0, 0.0}, {2.0, 1.0},
                                    {2.0, 2.0}};
  const PathSpeedResult result = PathSpeedPlanner(config).calculate(
      path, 0.0, 0.0, kMaximumSpeedMps, 1.0);
  EXPECT_FALSE(result.valid);
}

}  // namespace
}  // namespace vehicle_control

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
