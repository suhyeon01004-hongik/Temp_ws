# MORAI ROS1 스탠리 제어 코드

국민대 자료를 참고하되 새로 작성한 ROS1 C++ 제어 패키지다. 이 폴더 하나가
독립적인 catkin 패키지이며, 스탠리 횡제어부터 목표속도 결정, 가속·제동,
MORAI UDP 송신까지 포함한다.

## 데이터 흐름

```text
/local_path (nav_msgs/Path, base_link)
                         ┐
                         ├─> stanley_node
/localization/odometry   ┘       ├─> /vehicle/stanley_command
                                 ├─> /vehicle/target_speed_kph
                                 └─> /vehicle/stanley/* 디버그

/vehicle/stanley_command ──> morai_udp_sender_node ──> MORAI UDP
```

## 차량과 경로 조건

- ROS1 Noetic, C++14
- 축간거리: 3.0 m
- 최대 조향각: 40 deg
- 설정상 최대속도: 60 km/h
- 경로 좌표계: `base_link` 또는 `/base_link`
- 좌표 방향: `+x` 전방, `+y` 좌측
- 기본 경로: 0.5 m 간격 20점
- 속도 입력: Odometry의 `linear.x`, `linear.y` 평면 속도 크기

20점×0.5 m 경로에서는 보이는 거리가 짧으므로 60 km/h를 바로 지시하지
않는다. 계획 감속도 2.0 m/s²를 기준으로 경로 끝까지 감속 가능한 속도를
상한으로 사용한다. 충분히 긴 경로가 들어올 때만 60 km/h까지 올라간다.

경로에 NaN/Inf가 있거나, 경로·Odometry가 끊기거나, frame이 틀리거나,
차량 원점의 경로 투영이 모호하면 다음 안전 명령을 발행한다.

- 가속: `0.0`
- 브레이크: `0.5`
- 조향: `0.0`
- 목표속도 토픽: `0.0 km/h`

## 주요 파일

- `src/stanley_controller.cpp`: 스탠리 횡제어
- `src/path_speed_planner.cpp`: 곡률·오차·감속거리 기반 목표속도 계획
- `src/speed_controller.cpp`: 가속·브레이크 결정
- `src/stanley_node.cpp`: ROS 토픽 연결과 failsafe
- `src/morai_udp_sender_node.cpp`: VehicleCommand를 MORAI UDP로 전송
- `config/stanley.yaml`: 모든 튜닝값
- `launch/stanley_morai.launch`: 제어 노드와 UDP 노드 실행
- `test/`: 계산부 및 ROS 통합 테스트

## catkin workspace에 넣기

이 폴더를 workspace의 `src` 아래에 복사하거나 심볼릭 링크한다.

```bash
cd ~/catkin_ws/src
ln -s "$HOME/바탕화면/스탠리 코드 파일" vehicle_control
cd ..
catkin_make
source devel/setup.bash
```

같은 workspace에 이미 이름이 `vehicle_control`인 패키지가 있으면 둘 중
하나만 사용해야 한다.

## 실행

```bash
roslaunch vehicle_control stanley_morai.launch
```

MORAI가 다른 PC에 있으면 다음처럼 지정한다.

```bash
roslaunch vehicle_control stanley_morai.launch \
  destination_ip:=192.168.0.20 destination_port:=9093
```

기존 조이스틱 launch와 동시에 실행하면 안 된다. 두 UDP 송신기가 같은
차량에 서로 다른 명령을 보낼 수 있다.

## 확인할 토픽

```bash
rostopic hz /local_path
rostopic hz /localization/odometry
rostopic echo /vehicle/stanley_command
rostopic echo /vehicle/target_speed_kph
```

`/vehicle/target_speed_kph`의 타입은 `std_msgs/Float32`, 단위는 km/h다.

## 권장 주행 검토 순서

1. 바퀴를 띄우거나 정지 상태에서 좌우 조향 부호 확인
2. 저속 직선 주행
3. 저속 곡선 주행
4. Path/Odometry timeout 제동 확인
5. 로그를 보면서 속도를 단계적으로 증가

실차나 MORAI 맵에 맞게 조향 부호가 반대라면
`config/stanley.yaml`의 `steering_inverted`를 변경한다.
