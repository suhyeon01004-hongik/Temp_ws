#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <ros/ros.h>
#include <std_msgs/Float32.h>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "vehicle_control/VehicleCommand.h"
#include "vehicle_control/path_point.hpp"
#include "vehicle_control/path_speed_planner.hpp"
#include "vehicle_control/speed_controller.hpp"
#include "vehicle_control/stanley_controller.hpp"

namespace vehicle_control {
namespace {

constexpr double kPi = 3.14159265358979323846;
constexpr double kKphPerMps = 3.6;

bool isFinite(double value) {
  return std::isfinite(value);
}

bool isPositiveFinite(double value) {
  return isFinite(value) && value > 0.0;
}

bool isNonnegativeFinite(double value) {
  return isFinite(value) && value >= 0.0;
}

bool isUnitInterval(double value) {
  return isFinite(value) && value >= 0.0 && value <= 1.0;
}

void require(bool condition, const std::string& message) {
  if (!condition) {
    throw std::invalid_argument(message);
  }
}

}  // namespace

class StanleyNode {
 public:
  StanleyNode() : node_(), private_node_("~") {
    loadParameters();
    validateParameters();
    constructControllers();

    command_publisher_ =
        node_.advertise<VehicleCommand>(command_topic_, 10);
    target_speed_publisher_ =
        node_.advertise<std_msgs::Float32>(target_speed_topic_, 10);
    cross_track_error_publisher_ =
        node_.advertise<std_msgs::Float32>(
            "/vehicle/stanley/cross_track_error_m", 10);
    heading_error_publisher_ =
        node_.advertise<std_msgs::Float32>(
            "/vehicle/stanley/heading_error_deg", 10);
    curvature_publisher_ =
        node_.advertise<std_msgs::Float32>(
            "/vehicle/stanley/curvature", 10);

    path_subscriber_ =
        node_.subscribe(path_topic_, 10, &StanleyNode::pathCallback, this);
    odometry_subscriber_ = node_.subscribe(
        odometry_topic_, 10, &StanleyNode::odometryCallback, this);

    previous_iteration_time_ = ros::WallTime::now();
    control_timer_ = node_.createWallTimer(
        ros::WallDuration(1.0 / control_rate_hz_),
        &StanleyNode::controlCallback, this);

    ROS_INFO(
        "Stanley control: %s + %s -> %s; target speed -> %s at %.1f Hz",
        path_topic_.c_str(), odometry_topic_.c_str(),
        command_topic_.c_str(), target_speed_topic_.c_str(),
        control_rate_hz_);
  }

 private:
  void loadParameters() {
    private_node_.param<std::string>(
        "path_topic", path_topic_, "/local_path");
    private_node_.param<std::string>(
        "odometry_topic", odometry_topic_, "/localization/odometry");
    private_node_.param<std::string>(
        "command_topic", command_topic_, "/vehicle/stanley_command");
    private_node_.param<std::string>(
        "target_speed_topic", target_speed_topic_,
        "/vehicle/target_speed_kph");

    private_node_.param("control_rate_hz", control_rate_hz_, 50.0);
    private_node_.param("path_timeout", path_timeout_, 0.15);
    private_node_.param("odometry_timeout", odometry_timeout_, 0.20);
    private_node_.param("safe_brake", safe_brake_, 0.5);
    private_node_.param("expected_path_points", expected_path_points_, 20);
    private_node_.param(
        "expected_path_spacing_m", expected_path_spacing_m_, 0.5);
    private_node_.param(
        "path_spacing_tolerance_m", path_spacing_tolerance_m_, 0.2);

    private_node_.param("wheel_base_m", wheel_base_m_, 3.0);
    private_node_.param("stanley_gain", stanley_gain_, 1.0);
    private_node_.param("softening_gain", softening_gain_, 1.0);
    private_node_.param(
        "minimum_control_speed_mps", minimum_control_speed_mps_, 0.1);
    private_node_.param(
        "maximum_steering_angle_deg", maximum_steering_angle_deg_, 40.0);
    private_node_.param(
        "maximum_steering_rate_deg_per_sec",
        maximum_steering_rate_deg_per_sec_, 120.0);
    private_node_.param(
        "steering_inverted", steering_inverted_, false);

    private_node_.param("maximum_speed_kph", maximum_speed_kph_, 60.0);
    private_node_.param(
        "minimum_curve_speed_kph", minimum_curve_speed_kph_, 5.0);
    private_node_.param(
        "maximum_lateral_acceleration_mps2",
        maximum_lateral_acceleration_mps2_, 1.5);
    private_node_.param(
        "maximum_longitudinal_deceleration_mps2",
        maximum_longitudinal_deceleration_mps2_, 2.0);
    private_node_.param(
        "origin_projection_ambiguity_tolerance_m",
        origin_projection_ambiguity_tolerance_m_, 0.05);
    private_node_.param(
        "curvature_epsilon", curvature_epsilon_, 0.0001);
    private_node_.param(
        "speed_evaluation_start_m", speed_evaluation_start_m_, 2.0);
    private_node_.param(
        "speed_evaluation_end_m", speed_evaluation_end_m_, 8.0);
    private_node_.param(
        "heading_error_slowdown_gain",
        heading_error_slowdown_gain_, 1.5);
    private_node_.param(
        "cross_track_error_slowdown_gain",
        cross_track_error_slowdown_gain_, 0.5);
    private_node_.param(
        "target_speed_rise_kph_per_sec",
        target_speed_rise_kph_per_sec_, 5.0);
    private_node_.param(
        "target_speed_fall_kph_per_sec",
        target_speed_fall_kph_per_sec_, 20.0);

    private_node_.param("accelerator_gain", accelerator_gain_, 0.15);
    private_node_.param("brake_gain", brake_gain_, 0.20);
    private_node_.param(
        "speed_deadband_kph", speed_deadband_kph_, 0.5);
    private_node_.param(
        "maximum_accelerator_command",
        maximum_accelerator_command_, 0.4);
    private_node_.param(
        "maximum_brake_command", maximum_brake_command_, 0.6);
  }

  void validateParameters() const {
    require(!path_topic_.empty(), "path_topic must not be empty");
    require(!odometry_topic_.empty(), "odometry_topic must not be empty");
    require(!command_topic_.empty(), "command_topic must not be empty");
    require(
        !target_speed_topic_.empty(),
        "target_speed_topic must not be empty");

    require(
        isPositiveFinite(control_rate_hz_),
        "control_rate_hz must be positive and finite");
    require(
        isPositiveFinite(path_timeout_),
        "path_timeout must be positive and finite");
    require(
        isPositiveFinite(odometry_timeout_),
        "odometry_timeout must be positive and finite");
    require(
        isUnitInterval(safe_brake_),
        "safe_brake must be in [0, 1]");
    require(
        expected_path_points_ >= 2,
        "expected_path_points must be at least two");
    require(
        isPositiveFinite(expected_path_spacing_m_),
        "expected_path_spacing_m must be positive and finite");
    require(
        isNonnegativeFinite(path_spacing_tolerance_m_),
        "path_spacing_tolerance_m must be nonnegative and finite");

    require(
        isPositiveFinite(wheel_base_m_),
        "wheel_base_m must be positive and finite");
    require(
        isPositiveFinite(stanley_gain_),
        "stanley_gain must be positive and finite");
    require(
        isPositiveFinite(softening_gain_),
        "softening_gain must be positive and finite");
    require(
        isPositiveFinite(minimum_control_speed_mps_),
        "minimum_control_speed_mps must be positive and finite");
    require(
        isPositiveFinite(maximum_steering_angle_deg_),
        "maximum_steering_angle_deg must be positive and finite");
    require(
        isPositiveFinite(maximum_steering_rate_deg_per_sec_),
        "maximum_steering_rate_deg_per_sec must be positive and finite");

    require(
        isPositiveFinite(maximum_speed_kph_),
        "maximum_speed_kph must be positive and finite");
    require(
        isPositiveFinite(minimum_curve_speed_kph_),
        "minimum_curve_speed_kph must be positive and finite");
    require(
        minimum_curve_speed_kph_ <= maximum_speed_kph_,
        "minimum_curve_speed_kph must not exceed maximum_speed_kph");
    require(
        isPositiveFinite(maximum_lateral_acceleration_mps2_),
        "maximum_lateral_acceleration_mps2 must be positive and finite");
    require(
        isPositiveFinite(maximum_longitudinal_deceleration_mps2_),
        "maximum_longitudinal_deceleration_mps2 must be positive and finite");
    require(
        isNonnegativeFinite(origin_projection_ambiguity_tolerance_m_),
        "origin_projection_ambiguity_tolerance_m must be nonnegative and "
        "finite");
    require(
        isPositiveFinite(curvature_epsilon_),
        "curvature_epsilon must be positive and finite");
    require(
        isNonnegativeFinite(speed_evaluation_start_m_) &&
            isFinite(speed_evaluation_end_m_) &&
            speed_evaluation_end_m_ >= speed_evaluation_start_m_,
        "speed evaluation range must be finite, nonnegative, and ordered");
    require(
        isPositiveFinite(heading_error_slowdown_gain_),
        "heading_error_slowdown_gain must be positive and finite");
    require(
        isPositiveFinite(cross_track_error_slowdown_gain_),
        "cross_track_error_slowdown_gain must be positive and finite");
    require(
        isPositiveFinite(target_speed_rise_kph_per_sec_),
        "target_speed_rise_kph_per_sec must be positive and finite");
    require(
        isPositiveFinite(target_speed_fall_kph_per_sec_),
        "target_speed_fall_kph_per_sec must be positive and finite");

    require(
        isPositiveFinite(accelerator_gain_),
        "accelerator_gain must be positive and finite");
    require(
        isPositiveFinite(brake_gain_),
        "brake_gain must be positive and finite");
    require(
        isNonnegativeFinite(speed_deadband_kph_),
        "speed_deadband_kph must be nonnegative and finite");
    require(
        isPositiveFinite(maximum_accelerator_command_) &&
            isUnitInterval(maximum_accelerator_command_),
        "maximum_accelerator_command must be in (0, 1]");
    require(
        isPositiveFinite(maximum_brake_command_) &&
            isUnitInterval(maximum_brake_command_),
        "maximum_brake_command must be in (0, 1]");
  }

  void constructControllers() {
    const double degrees_to_radians = kPi / 180.0;
    const StanleyConfig stanley_config{
        wheel_base_m_,
        stanley_gain_,
        softening_gain_,
        minimum_control_speed_mps_,
        maximum_steering_angle_deg_ * degrees_to_radians,
        maximum_steering_rate_deg_per_sec_ * degrees_to_radians};
    const PathSpeedConfig path_speed_config{
        maximum_speed_kph_ / kKphPerMps,
        minimum_curve_speed_kph_ / kKphPerMps,
        maximum_lateral_acceleration_mps2_,
        maximum_longitudinal_deceleration_mps2_,
        origin_projection_ambiguity_tolerance_m_,
        curvature_epsilon_,
        speed_evaluation_start_m_,
        speed_evaluation_end_m_,
        heading_error_slowdown_gain_,
        cross_track_error_slowdown_gain_,
        target_speed_rise_kph_per_sec_ / kKphPerMps,
        target_speed_fall_kph_per_sec_ / kKphPerMps};
    const SpeedControllerConfig speed_controller_config{
        accelerator_gain_,
        brake_gain_,
        speed_deadband_kph_ / kKphPerMps,
        maximum_accelerator_command_,
        maximum_brake_command_};

    stanley_controller_.reset(new StanleyController(stanley_config));
    path_speed_planner_.reset(new PathSpeedPlanner(path_speed_config));
    speed_controller_.reset(new SpeedController(speed_controller_config));
    previous_target_speed_mps_ = 0.0;
    maximum_steering_angle_rad_ =
        maximum_steering_angle_deg_ * degrees_to_radians;
  }

  void pathCallback(const nav_msgs::Path::ConstPtr& message) {
    path_reception_time_ = ros::WallTime::now();
    has_path_ = true;
    path_valid_ = false;
    path_.clear();

    std::string frame_id = message->header.frame_id;
    if (!frame_id.empty() && frame_id.front() == '/') {
      frame_id.erase(frame_id.begin());
    }
    if (frame_id != "base_link") {
      ROS_WARN_THROTTLE(
          1.0, "Stanley path frame must be base_link, received '%s'",
          message->header.frame_id.c_str());
      return;
    }

    path_.reserve(message->poses.size());
    for (const geometry_msgs::PoseStamped& pose : message->poses) {
      const double x = pose.pose.position.x;
      const double y = pose.pose.position.y;
      if (!isFinite(x) || !isFinite(y)) {
        path_.clear();
        ROS_WARN_THROTTLE(
            1.0, "Stanley path contains a nonfinite position");
        return;
      }
      path_.push_back(PathPoint{x, y});
    }
    path_valid_ = true;

    if (path_.size() != static_cast<std::size_t>(expected_path_points_)) {
      ROS_WARN_THROTTLE(
          1.0, "Stanley path has %zu points; expected %d",
          path_.size(), expected_path_points_);
    }
    if (path_.size() >= 2U) {
      double total_spacing = 0.0;
      bool spacing_finite = true;
      for (std::size_t index = 1U; index < path_.size(); ++index) {
        const double spacing = std::hypot(
            path_[index].x - path_[index - 1U].x,
            path_[index].y - path_[index - 1U].y);
        if (!isFinite(spacing)) {
          spacing_finite = false;
          break;
        }
        total_spacing += spacing;
      }
      const double mean_spacing =
          total_spacing / static_cast<double>(path_.size() - 1U);
      if (!spacing_finite || !isFinite(mean_spacing) ||
          std::abs(mean_spacing - expected_path_spacing_m_) >
              path_spacing_tolerance_m_) {
        ROS_WARN_THROTTLE(
            1.0,
            "Stanley path mean spacing is %.3f m; expected %.3f +/- %.3f m",
            mean_spacing, expected_path_spacing_m_,
            path_spacing_tolerance_m_);
      }
    }
  }

  void odometryCallback(const nav_msgs::Odometry::ConstPtr& message) {
    odometry_reception_time_ = ros::WallTime::now();
    has_odometry_ = true;
    odometry_valid_ = false;

    const double speed_x = message->twist.twist.linear.x;
    const double speed_y = message->twist.twist.linear.y;
    if (!isFinite(speed_x) || !isFinite(speed_y)) {
      ROS_WARN_THROTTLE(
          1.0, "Stanley odometry planar velocity must be finite");
      return;
    }

    const double speed_mps = std::hypot(speed_x, speed_y);
    if (!isFinite(speed_mps)) {
      ROS_WARN_THROTTLE(
          1.0, "Stanley odometry planar speed must be finite");
      return;
    }
    speed_mps_ = speed_mps;
    odometry_valid_ = true;
  }

  void controlCallback(const ros::WallTimerEvent&) {
    const ros::WallTime now = ros::WallTime::now();
    const double dt_sec = (now - previous_iteration_time_).toSec();
    previous_iteration_time_ = now;

    if (!isPositiveFinite(dt_sec) || !inputsFresh(now)) {
      publishSafeCommand();
      return;
    }

    const StanleyResult stanley_result = stanley_controller_->calculate(
        path_, speed_mps_, previous_steering_angle_rad_, dt_sec);
    if (!stanley_result.valid) {
      ROS_WARN_THROTTLE(
          1.0, "Stanley calculation failed: %s",
          stanley_result.error.c_str());
      publishSafeCommand();
      return;
    }

    const PathSpeedResult speed_result = path_speed_planner_->calculate(
        path_, stanley_result.heading_error_rad,
        stanley_result.cross_track_error_m,
        previous_target_speed_mps_, dt_sec);
    if (!speed_result.valid) {
      ROS_WARN_THROTTLE(
          1.0, "Stanley speed planning failed: %s",
          speed_result.error.c_str());
      publishSafeCommand();
      return;
    }

    const PedalCommand pedal_command = speed_controller_->calculate(
        speed_mps_, speed_result.target_speed_mps);
    if (!pedal_command.valid) {
      ROS_WARN_THROTTLE(
          1.0, "Stanley speed control failed: %s",
          pedal_command.error.c_str());
      publishSafeCommand();
      return;
    }

    double normalized_steering =
        stanley_result.steering_angle_rad /
        maximum_steering_angle_rad_;
    if (steering_inverted_) {
      normalized_steering = -normalized_steering;
    }
    normalized_steering =
        std::max(-1.0, std::min(1.0, normalized_steering));
    if (!isFinite(normalized_steering)) {
      ROS_WARN_THROTTLE(
          1.0, "Stanley normalized steering is nonfinite");
      publishSafeCommand();
      return;
    }

    VehicleCommand command;
    command.header.stamp = ros::Time::now();
    command.accel = static_cast<float>(pedal_command.accelerator);
    command.brake = static_cast<float>(pedal_command.brake);
    command.steering = static_cast<float>(normalized_steering);
    command.gear = VehicleCommand::GEAR_DRIVE;
    command_publisher_.publish(command);

    publishFloat(
        target_speed_publisher_,
        speed_result.target_speed_mps * kKphPerMps);
    publishFloat(
        cross_track_error_publisher_,
        stanley_result.cross_track_error_m);
    publishFloat(
        heading_error_publisher_,
        stanley_result.heading_error_rad * 180.0 / kPi);
    publishFloat(
        curvature_publisher_,
        speed_result.representative_curvature);

    previous_steering_angle_rad_ =
        stanley_result.steering_angle_rad;
    previous_target_speed_mps_ = speed_result.target_speed_mps;
  }

  bool inputsFresh(const ros::WallTime& now) const {
    if (!has_path_ || !path_valid_ ||
        !has_odometry_ || !odometry_valid_) {
      return false;
    }
    const double path_age = (now - path_reception_time_).toSec();
    const double odometry_age =
        (now - odometry_reception_time_).toSec();
    return isNonnegativeFinite(path_age) &&
           path_age <= path_timeout_ &&
           isNonnegativeFinite(odometry_age) &&
           odometry_age <= odometry_timeout_;
  }

  void publishSafeCommand() {
    previous_steering_angle_rad_ = 0.0;
    previous_target_speed_mps_ = 0.0;

    VehicleCommand command;
    command.header.stamp = ros::Time::now();
    command.accel = 0.0F;
    command.brake = static_cast<float>(safe_brake_);
    command.steering = 0.0F;
    command.gear = VehicleCommand::GEAR_DRIVE;
    command_publisher_.publish(command);
    publishFloat(target_speed_publisher_, 0.0);
  }

  static void publishFloat(
      const ros::Publisher& publisher, double value) {
    std_msgs::Float32 message;
    message.data = static_cast<float>(value);
    publisher.publish(message);
  }

  ros::NodeHandle node_;
  ros::NodeHandle private_node_;
  ros::Subscriber path_subscriber_;
  ros::Subscriber odometry_subscriber_;
  ros::Publisher command_publisher_;
  ros::Publisher target_speed_publisher_;
  ros::Publisher cross_track_error_publisher_;
  ros::Publisher heading_error_publisher_;
  ros::Publisher curvature_publisher_;
  ros::WallTimer control_timer_;

  std::string path_topic_;
  std::string odometry_topic_;
  std::string command_topic_;
  std::string target_speed_topic_;
  double control_rate_hz_{50.0};
  double path_timeout_{0.15};
  double odometry_timeout_{0.20};
  double safe_brake_{0.5};
  int expected_path_points_{20};
  double expected_path_spacing_m_{0.5};
  double path_spacing_tolerance_m_{0.2};
  double wheel_base_m_{3.0};
  double stanley_gain_{1.0};
  double softening_gain_{1.0};
  double minimum_control_speed_mps_{0.1};
  double maximum_steering_angle_deg_{40.0};
  double maximum_steering_rate_deg_per_sec_{120.0};
  bool steering_inverted_{false};
  double maximum_speed_kph_{60.0};
  double minimum_curve_speed_kph_{5.0};
  double maximum_lateral_acceleration_mps2_{1.5};
  double maximum_longitudinal_deceleration_mps2_{2.0};
  double origin_projection_ambiguity_tolerance_m_{0.05};
  double curvature_epsilon_{0.0001};
  double speed_evaluation_start_m_{2.0};
  double speed_evaluation_end_m_{8.0};
  double heading_error_slowdown_gain_{1.5};
  double cross_track_error_slowdown_gain_{0.5};
  double target_speed_rise_kph_per_sec_{5.0};
  double target_speed_fall_kph_per_sec_{20.0};
  double accelerator_gain_{0.15};
  double brake_gain_{0.20};
  double speed_deadband_kph_{0.5};
  double maximum_accelerator_command_{0.4};
  double maximum_brake_command_{0.6};
  double maximum_steering_angle_rad_{0.0};

  std::unique_ptr<StanleyController> stanley_controller_;
  std::unique_ptr<PathSpeedPlanner> path_speed_planner_;
  std::unique_ptr<SpeedController> speed_controller_;
  std::vector<PathPoint> path_;
  bool has_path_{false};
  bool path_valid_{false};
  ros::WallTime path_reception_time_;
  bool has_odometry_{false};
  bool odometry_valid_{false};
  ros::WallTime odometry_reception_time_;
  double speed_mps_{0.0};
  ros::WallTime previous_iteration_time_;
  double previous_steering_angle_rad_{0.0};
  double previous_target_speed_mps_{0.0};
};

}  // namespace vehicle_control

int main(int argc, char** argv) {
  ros::init(argc, argv, "stanley_node");
  try {
    vehicle_control::StanleyNode node;
    ros::spin();
  } catch (const std::exception& error) {
    ROS_FATAL("Stanley node configuration failed: %s", error.what());
    return 1;
  }
  return 0;
}
