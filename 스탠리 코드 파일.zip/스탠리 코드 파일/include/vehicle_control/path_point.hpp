#pragma once

namespace vehicle_control {

struct PathPoint {
  double x;
  double y;
};

}  // namespace vehicle_control
