#include "vehicle_control/speed_controller.hpp"

#include <algorithm>
#include <cmath>
#include <string>

namespace vehicle_control {
namespace {

PedalCommand invalidCommand(const std::string& error) {
  return PedalCommand{false, 0.0, 0.0, error};
}

bool isFinite(double value) {
  return std::isfinite(value);
}

bool isPositiveFinite(double value) {
  return isFinite(value) && value > 0.0;
}

bool isNonnegativeFinite(double value) {
  return isFinite(value) && value >= 0.0;
}

std::string configurationError(const SpeedControllerConfig& config) {
  if (!isPositiveFinite(config.accelerator_gain)) {
    return "accelerator gain must be positive and finite";
  }
  if (!isPositiveFinite(config.brake_gain)) {
    return "brake gain must be positive and finite";
  }
  if (!isNonnegativeFinite(config.deadband_mps)) {
    return "speed deadband must be nonnegative and finite";
  }
  if (!isPositiveFinite(config.maximum_accelerator_command)) {
    return "maximum accelerator command must be positive and finite";
  }
  if (!isPositiveFinite(config.maximum_brake_command)) {
    return "maximum brake command must be positive and finite";
  }
  return std::string();
}

}  // namespace

SpeedController::SpeedController(const SpeedControllerConfig& config)
    : config_(config),
      config_valid_(false),
      config_error_(configurationError(config)) {
  config_valid_ = config_error_.empty();
}

PedalCommand SpeedController::calculate(double current_speed_mps,
                                        double target_speed_mps) const {
  if (!config_valid_) {
    return invalidCommand("invalid speed controller configuration: " +
                          config_error_);
  }
  if (!isNonnegativeFinite(current_speed_mps) ||
      !isNonnegativeFinite(target_speed_mps)) {
    return invalidCommand("speed controller inputs must be finite and nonnegative");
  }

  const double speed_error = target_speed_mps - current_speed_mps;
  if (std::abs(speed_error) <= config_.deadband_mps) {
    return PedalCommand{true, 0.0, 0.0, std::string()};
  }
  if (speed_error > 0.0) {
    const double accelerator = std::min(
        config_.maximum_accelerator_command,
        config_.accelerator_gain * speed_error);
    return PedalCommand{true, accelerator, 0.0, std::string()};
  }

  const double brake = std::min(config_.maximum_brake_command,
                                config_.brake_gain * -speed_error);
  return PedalCommand{true, 0.0, brake, std::string()};
}

}  // namespace vehicle_control
