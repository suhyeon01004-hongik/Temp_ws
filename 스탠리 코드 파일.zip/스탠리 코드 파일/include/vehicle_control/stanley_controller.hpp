#pragma once

#include <cstddef>
#include <string>
#include <vector>

#include "vehicle_control/path_point.hpp"

namespace vehicle_control {

struct StanleyConfig {
  double wheel_base_m;
  double gain;
  double softening_gain;
  double minimum_control_speed_mps;
  double maximum_steering_angle_rad;
  double maximum_steering_rate_rad_per_sec;
};

struct StanleyResult {
  bool valid;
  double steering_angle_rad;
  double cross_track_error_m;
  double heading_error_rad;
  double target_x;
  double target_y;
  std::size_t target_segment_index;
  std::string error;
};

class StanleyController {
 public:
  explicit StanleyController(const StanleyConfig& config);

  StanleyResult calculate(const std::vector<PathPoint>& path,
                          double speed_mps,
                          double previous_steering_angle_rad,
                          double dt_sec) const;

 private:
  StanleyConfig config_;
  bool config_valid_;
  std::string config_error_;
};

}  // namespace vehicle_control
