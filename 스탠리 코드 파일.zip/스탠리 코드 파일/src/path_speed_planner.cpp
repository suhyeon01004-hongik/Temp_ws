#include "vehicle_control/path_speed_planner.hpp"

#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

namespace vehicle_control {
namespace {

PathSpeedResult invalidResult(const std::string& error) {
  return PathSpeedResult{false, 0.0, 0.0, error};
}

bool isFinite(double value) {
  return std::isfinite(value);
}

bool isPositiveFinite(double value) {
  return isFinite(value) && value > 0.0;
}

bool isNonnegativeFinite(double value) {
  return isFinite(value) && value >= 0.0;
}

struct CurvatureSample {
  double curvature;
  double distance_m;
};

struct ProjectionCandidate {
  double distance_m;
  double station_m;
};

constexpr double kStationEquivalenceToleranceM = 1e-6;

std::string configurationError(const PathSpeedConfig& config) {
  if (!isPositiveFinite(config.maximum_speed_mps)) {
    return "maximum speed must be positive and finite";
  }
  if (!isPositiveFinite(config.minimum_curve_speed_mps)) {
    return "minimum curve speed must be positive and finite";
  }
  if (config.minimum_curve_speed_mps > config.maximum_speed_mps) {
    return "minimum curve speed must not exceed maximum speed";
  }
  if (!isPositiveFinite(config.maximum_lateral_acceleration_mps2)) {
    return "maximum lateral acceleration must be positive and finite";
  }
  if (!isPositiveFinite(config.maximum_longitudinal_deceleration_mps2)) {
    return "maximum longitudinal deceleration must be positive and finite";
  }
  if (!isNonnegativeFinite(
          config.origin_projection_ambiguity_tolerance_m)) {
    return "origin projection ambiguity tolerance must be nonnegative and "
           "finite";
  }
  if (!isPositiveFinite(config.curvature_epsilon)) {
    return "curvature epsilon must be positive and finite";
  }
  if (!isNonnegativeFinite(config.evaluation_start_m) ||
      !isFinite(config.evaluation_end_m) ||
      config.evaluation_end_m < config.evaluation_start_m) {
    return "evaluation range must be finite, nonnegative, and ordered";
  }
  if (!isNonnegativeFinite(config.heading_error_slowdown_gain)) {
    return "heading error slowdown gain must be nonnegative and finite";
  }
  if (!isNonnegativeFinite(config.cross_track_error_slowdown_gain)) {
    return "cross-track error slowdown gain must be nonnegative and finite";
  }
  if (!isPositiveFinite(config.target_speed_rise_mps2)) {
    return "target speed rise limit must be positive and finite";
  }
  if (!isPositiveFinite(config.target_speed_fall_mps2)) {
    return "target speed fall limit must be positive and finite";
  }
  return std::string();
}

double distance(const PathPoint& first, const PathPoint& second) {
  return std::hypot(second.x - first.x, second.y - first.y);
}

bool samePoint(const PathPoint& first, const PathPoint& second) {
  return first.x == second.x && first.y == second.y;
}

bool triangleCurvature(const PathPoint& first, const PathPoint& second,
                       const PathPoint& third, double* curvature) {
  const double side_a = distance(first, second);
  const double side_b = distance(second, third);
  const double side_c = distance(third, first);
  const double cross_product =
      (second.x - first.x) * (third.y - first.y) -
      (second.y - first.y) * (third.x - first.x);
  const double denominator = side_a * side_b * side_c;
  if (!isFinite(side_a) || !isFinite(side_b) || !isFinite(side_c) ||
      !isFinite(cross_product) || !isFinite(denominator)) {
    return false;
  }
  if (denominator <= 0.0) {
    return true;
  }
  *curvature = std::abs(2.0 * cross_product / denominator);
  return isFinite(*curvature);
}

bool brakingReachableSpeed(double terminal_speed_mps, double distance_m,
                          double deceleration_mps2, double* speed_mps) {
  const double terminal_speed_squared =
      terminal_speed_mps * terminal_speed_mps;
  const double distance_term = 2.0 * deceleration_mps2 * distance_m;
  const double speed_squared = terminal_speed_squared + distance_term;
  if (!isNonnegativeFinite(terminal_speed_squared) ||
      !isNonnegativeFinite(distance_term) ||
      !isNonnegativeFinite(speed_squared)) {
    return false;
  }
  *speed_mps = std::sqrt(speed_squared);
  return isNonnegativeFinite(*speed_mps);
}

bool closestOriginStation(const std::vector<PathPoint>& path,
                          const std::vector<double>& cumulative_distance,
                          double ambiguity_tolerance_m,
                          double* origin_station_m,
                          bool* projection_is_ambiguous) {
  std::vector<ProjectionCandidate> candidates;
  *projection_is_ambiguous = false;

  for (std::size_t index = 1U; index < path.size(); ++index) {
    const PathPoint& start = path[index - 1U];
    const PathPoint& end = path[index];
    const double delta_x = end.x - start.x;
    const double delta_y = end.y - start.y;
    const double segment_length = distance(start, end);
    if (!isFinite(delta_x) || !isFinite(delta_y) ||
        !isPositiveFinite(segment_length)) {
      return false;
    }

    const double unit_x = delta_x / segment_length;
    const double unit_y = delta_y / segment_length;
    const double start_along_x = start.x * unit_x;
    const double start_along_y = start.y * unit_y;
    const double start_along = start_along_x + start_along_y;
    if (!isFinite(unit_x) || !isFinite(unit_y) ||
        !isFinite(start_along_x) || !isFinite(start_along_y) ||
        !isFinite(start_along)) {
      return false;
    }

    const double along_segment_m =
        std::max(0.0, std::min(segment_length, -start_along));
    const double projection_delta_x = unit_x * along_segment_m;
    const double projection_delta_y = unit_y * along_segment_m;
    const double projection_x = start.x + projection_delta_x;
    const double projection_y = start.y + projection_delta_y;
    const double projection_distance_m =
        std::hypot(projection_x, projection_y);
    const double projection_station_m =
        cumulative_distance[index - 1U] + along_segment_m;
    if (!isNonnegativeFinite(along_segment_m) ||
        !isFinite(projection_delta_x) ||
        !isFinite(projection_delta_y) ||
        !isFinite(projection_x) || !isFinite(projection_y) ||
        !isNonnegativeFinite(projection_distance_m) ||
        !isNonnegativeFinite(projection_station_m)) {
      return false;
    }

    candidates.push_back(
        ProjectionCandidate{projection_distance_m, projection_station_m});
  }

  if (candidates.empty() || !isNonnegativeFinite(ambiguity_tolerance_m)) {
    return false;
  }

  const ProjectionCandidate* closest_candidate = &candidates.front();
  for (const ProjectionCandidate& candidate : candidates) {
    if (candidate.distance_m < closest_candidate->distance_m) {
      closest_candidate = &candidate;
    }
  }

  const double ambiguity_distance_limit_m =
      closest_candidate->distance_m + ambiguity_tolerance_m;
  if (!isNonnegativeFinite(ambiguity_distance_limit_m)) {
    return false;
  }

  for (const ProjectionCandidate& candidate : candidates) {
    if (candidate.distance_m <= ambiguity_distance_limit_m) {
      const double station_difference_m =
          std::abs(candidate.station_m - closest_candidate->station_m);
      if (!isNonnegativeFinite(station_difference_m)) {
        return false;
      }
      if (station_difference_m > kStationEquivalenceToleranceM) {
        *projection_is_ambiguous = true;
        return false;
      }
    }
  }

  *origin_station_m = closest_candidate->station_m;
  return isNonnegativeFinite(*origin_station_m);
}

}  // namespace

PathSpeedPlanner::PathSpeedPlanner(const PathSpeedConfig& config)
    : config_(config),
      config_valid_(false),
      config_error_(configurationError(config)) {
  config_valid_ = config_error_.empty();
}

PathSpeedResult PathSpeedPlanner::calculate(
    const std::vector<PathPoint>& path, double heading_error_rad,
    double cross_track_error_m, double previous_target_speed_mps,
    double dt_sec) const {
  if (!config_valid_) {
    return invalidResult("invalid path speed configuration: " + config_error_);
  }
  if (!isFinite(heading_error_rad) || !isFinite(cross_track_error_m) ||
      !isFinite(previous_target_speed_mps) ||
      !isPositiveFinite(dt_sec)) {
    return invalidResult("speed planner inputs must be finite with positive timestep");
  }
  if (previous_target_speed_mps < 0.0 ||
      previous_target_speed_mps > config_.maximum_speed_mps) {
    return invalidResult(
        "previous target speed must be within [0, maximum speed]");
  }

  std::vector<PathPoint> distinct_path;
  distinct_path.reserve(path.size());
  for (const PathPoint& point : path) {
    if (!isFinite(point.x) || !isFinite(point.y)) {
      return invalidResult("path points must be finite");
    }
    if (distinct_path.empty() || !samePoint(distinct_path.back(), point)) {
      distinct_path.push_back(point);
    }
  }
  if (distinct_path.size() < 2U) {
    return invalidResult("path requires at least two finite distinct points");
  }

  std::vector<double> cumulative_distance(distinct_path.size(), 0.0);
  for (std::size_t index = 1U; index < distinct_path.size(); ++index) {
    const double segment_length =
        distance(distinct_path[index - 1U], distinct_path[index]);
    if (!isPositiveFinite(segment_length)) {
      return invalidResult("path contains an invalid segment");
    }
    cumulative_distance[index] =
        cumulative_distance[index - 1U] + segment_length;
    if (!isFinite(cumulative_distance[index]) ||
        cumulative_distance[index] <=
            cumulative_distance[index - 1U]) {
      return invalidResult("path distance is nonfinite");
    }
  }

  double origin_station_m = 0.0;
  bool origin_projection_is_ambiguous = false;
  if (!closestOriginStation(distinct_path, cumulative_distance,
                            config_.origin_projection_ambiguity_tolerance_m,
                            &origin_station_m,
                            &origin_projection_is_ambiguous)) {
    if (origin_projection_is_ambiguous) {
      return invalidResult("path origin projection is ambiguous");
    }
    return invalidResult("path origin projection is invalid");
  }

  double representative_curvature = 0.0;
  std::vector<CurvatureSample> curvature_samples;
  if (distinct_path.size() > 2U) {
    std::vector<double> forward_curvatures;
    std::vector<double> eligible_curvatures;
    for (std::size_t index = 1U; index + 1U < distinct_path.size(); ++index) {
      double curvature = 0.0;
      if (!triangleCurvature(distinct_path[index - 1U], distinct_path[index],
                             distinct_path[index + 1U], &curvature)) {
        return invalidResult("path curvature is nonfinite");
      }
      const double sample_station_m = cumulative_distance[index];
      if (sample_station_m >= origin_station_m) {
        const double forward_distance_m =
            sample_station_m - origin_station_m;
        if (!isNonnegativeFinite(forward_distance_m)) {
          return invalidResult(
              "curvature sample station is invalid");
        }
        curvature_samples.push_back(
            CurvatureSample{curvature, forward_distance_m});
        forward_curvatures.push_back(curvature);
        if (forward_distance_m >= config_.evaluation_start_m &&
            forward_distance_m <= config_.evaluation_end_m) {
          eligible_curvatures.push_back(curvature);
        }
      }
    }

    if (!forward_curvatures.empty()) {
      const std::vector<double>& selected_curvatures =
          eligible_curvatures.size() >= 2U
              ? eligible_curvatures
              : forward_curvatures;
      std::vector<double> sorted_curvatures(selected_curvatures);
      std::sort(sorted_curvatures.begin(), sorted_curvatures.end());
      const double maximum_curvature = sorted_curvatures.back();
      const std::size_t percentile_index = static_cast<std::size_t>(
          std::floor(
              0.8 * static_cast<double>(sorted_curvatures.size() - 1U)));
      representative_curvature =
          std::max(sorted_curvatures[percentile_index],
                   0.8 * maximum_curvature);
    }
  }

  const double curvature_for_speed =
      std::max(representative_curvature, config_.curvature_epsilon);
  const double curve_speed = std::sqrt(
      config_.maximum_lateral_acceleration_mps2 / curvature_for_speed);
  const double heading_slowdown =
      config_.heading_error_slowdown_gain * std::abs(heading_error_rad);
  const double cross_track_slowdown =
      config_.cross_track_error_slowdown_gain *
      std::abs(cross_track_error_m);
  const double heading_denominator = 1.0 + heading_slowdown;
  const double cross_track_denominator = 1.0 + cross_track_slowdown;
  if (!isNonnegativeFinite(heading_slowdown) ||
      !isNonnegativeFinite(cross_track_slowdown) ||
      !isPositiveFinite(heading_denominator) ||
      !isPositiveFinite(cross_track_denominator)) {
    return invalidResult(
        "speed planner slowdown calculation overflowed");
  }
  const double heading_scale =
      1.0 / heading_denominator;
  const double cross_track_scale =
      1.0 / cross_track_denominator;
  const double raw_target =
      std::min(config_.maximum_speed_mps, curve_speed) * heading_scale *
      cross_track_scale;
  if (!isFinite(representative_curvature) || !isFinite(curve_speed) ||
      !isFinite(heading_scale) || !isFinite(cross_track_scale) ||
      !isFinite(raw_target)) {
    return invalidResult("speed planner calculation produced a nonfinite result");
  }

  const double bounded_target =
      std::max(config_.minimum_curve_speed_mps,
               std::min(config_.maximum_speed_mps, raw_target));
  const double maximum_rise = config_.target_speed_rise_mps2 * dt_sec;
  const double maximum_fall = config_.target_speed_fall_mps2 * dt_sec;
  const double lower_rate_bound =
      previous_target_speed_mps - maximum_fall;
  const double upper_rate_bound =
      previous_target_speed_mps + maximum_rise;
  if (!isFinite(maximum_rise) || !isFinite(maximum_fall) ||
      !isFinite(lower_rate_bound) || !isFinite(upper_rate_bound)) {
    return invalidResult("speed planner rate limit overflowed");
  }
  const double rate_limited_target =
      std::max(lower_rate_bound,
               std::min(upper_rate_bound, bounded_target));
  if (!isFinite(rate_limited_target)) {
    return invalidResult("speed planner rate limit produced a nonfinite result");
  }

  double hard_safety_ceiling = config_.maximum_speed_mps;
  for (const CurvatureSample& sample : curvature_samples) {
    const double sample_curvature =
        std::max(sample.curvature, config_.curvature_epsilon);
    const double unbounded_sample_curve_speed =
        std::sqrt(config_.maximum_lateral_acceleration_mps2 /
                  sample_curvature);
    if (!isPositiveFinite(unbounded_sample_curve_speed)) {
      return invalidResult(
          "curvature sample speed produced a nonfinite result");
    }
    const double sample_curve_speed =
        std::min(config_.maximum_speed_mps,
                 unbounded_sample_curve_speed);
    double reachable_speed = 0.0;
    if (!isPositiveFinite(sample_curve_speed) ||
        !brakingReachableSpeed(
            sample_curve_speed, sample.distance_m,
            config_.maximum_longitudinal_deceleration_mps2,
            &reachable_speed)) {
      return invalidResult(
          "curvature safety ceiling produced a nonfinite result");
    }
    hard_safety_ceiling =
        std::min(hard_safety_ceiling, reachable_speed);
  }

  double terminal_reachable_speed = 0.0;
  const double terminal_horizon_m = std::max(
      0.0, cumulative_distance.back() - origin_station_m);
  if (!isNonnegativeFinite(terminal_horizon_m)) {
    return invalidResult("terminal horizon is invalid");
  }
  if (!brakingReachableSpeed(
          config_.minimum_curve_speed_mps, terminal_horizon_m,
          config_.maximum_longitudinal_deceleration_mps2,
          &terminal_reachable_speed)) {
    return invalidResult(
        "terminal safety ceiling produced a nonfinite result");
  }
  hard_safety_ceiling =
      std::min(hard_safety_ceiling, terminal_reachable_speed);

  const double final_target =
      std::min(rate_limited_target, hard_safety_ceiling);
  if (!isNonnegativeFinite(hard_safety_ceiling) ||
      !isNonnegativeFinite(final_target) ||
      final_target > config_.maximum_speed_mps) {
    return invalidResult("speed safety ceiling produced an invalid result");
  }

  return PathSpeedResult{true, final_target, representative_curvature,
                         std::string()};
}

}  // namespace vehicle_control
